package com.example.samsung.login;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class EnviarLoc extends Service {

    private String HOST = "http://192.168.43.232/login";

    public static String getUniqueIMEIId(Context context) {
        try {
            TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return "";
            }
            String imei = telephonyManager.getDeviceId();
            Log.e("imei", "=" + imei);
            if (imei != null && !imei.isEmpty()) {
                return imei;
            } else {
                return android.os.Build.SERIAL;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "not_found";
    }

    public void enviar(String latitude, String longitude){
        //ion
                        String URL = HOST + "/insereLoc.php";

                        String celular = getUniqueIMEIId(EnviarLoc.this);

                        Ion.with(EnviarLoc.this)
                                .load(URL)
                                .setBodyParameter("lat_app",latitude)
                                .setBodyParameter("celular_app",celular)
                                .setBodyParameter("long_app",longitude)
                                .asJsonObject()
                                .setCallback(new FutureCallback<JsonObject>() {
                                    @Override
                                    public void onCompleted(Exception e, JsonObject result) {

                                        try {
                                            String RETORNO = result.get("DISTANCIA").getAsString();
                                            if (RETORNO.equals("ERRO")) {
                                                Toast.makeText(EnviarLoc.this, "Ocorreu um erro no envio da localização", Toast.LENGTH_LONG).show();
                                            } else if (RETORNO.equals("UPDATE")) {
                                                Toast.makeText(EnviarLoc.this, "Enviado a localizao", Toast.LENGTH_LONG).show();


                                            }} catch(Exception erro){
                                                Toast.makeText(EnviarLoc.this, "Um erro ocorreu " + erro, Toast.LENGTH_LONG).show();
                                            }
                                        }
                                });
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
