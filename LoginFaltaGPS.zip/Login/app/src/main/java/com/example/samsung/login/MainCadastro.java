package com.example.samsung.login;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.gson.JsonObject;
import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;

public class MainCadastro extends AppCompatActivity {

    private EditText editNomeCad, editCelularCad, editSenhaCad, editSenhaConf;
    private Button btnCadastrar;

    //HOST configurado para XAMPP, mudar de acordo com a maquina
    //private String HOST = "http://thalesathayde.github.io/LabMobile";
    private String HOST = "http://192.168.1.104/login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_cadastro);

        editNomeCad = (EditText) findViewById(R.id.editNomeCad);
        editCelularCad = (EditText) findViewById(R.id.editCelularCad);
        editSenhaCad = (EditText) findViewById(R.id.editSenhaCad);
        editSenhaConf = (EditText) findViewById(R.id.editSenhaConf);
        btnCadastrar = (Button) findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nome = editNomeCad.getText().toString();
                String celular = editCelularCad.getText().toString();
                String senha = editSenhaCad.getText().toString();
                String confirma = editSenhaConf.getText().toString();
                String URL = HOST + "/cadastrar.php";


                if(confirma.equals(senha)){

                    if(nome.isEmpty() || celular.isEmpty() || senha.isEmpty()){
                        Toast.makeText(MainCadastro.this, "Os campos acima são obrigatórios", Toast.LENGTH_LONG).show();
                    }else {

                        Ion.with(MainCadastro.this)
                                .load(URL)
                                .setBodyParameter("nome_app",nome)
                                .setBodyParameter("celular_app",celular)
                                .setBodyParameter("senha_app",senha)
                                .asJsonObject()
                                .setCallback(new FutureCallback<JsonObject>() {
                                    @Override
                                    public void onCompleted(Exception e, JsonObject result) {

                                        try {
                                            //Toast.makeText(MainCadastro.this, "Retorno: " + result.toString(), Toast.LENGTH_LONG).show();
                                            String RETORNO = result.get("CADASTRO").getAsString();
                                            if(RETORNO.equals("CELULAR_ERRO")){
                                                Toast.makeText(MainCadastro.this, "Celular já cadastado", Toast.LENGTH_LONG).show();
                                            }else if(RETORNO.equals("SUCESSO")){
                                                Toast.makeText(MainCadastro.this, "Cadastrado com sucesso", Toast.LENGTH_LONG).show();
                                                Intent abrePrincipal = new Intent(MainCadastro.this,MainFuncoes.class);
                                                //Intent abrePrincipal = new Intent(MainCadastro.this,TesteAct.class);
                                                startActivity(abrePrincipal);
                                            }else{
                                                Toast.makeText(MainCadastro.this, "Erro ", Toast.LENGTH_LONG).show();
                                            }

                                        } catch (Exception erro) {
                                            Toast.makeText(MainCadastro.this, "Um erro ocorreu " + erro, Toast.LENGTH_LONG).show();
                                        }
                                    }
                                });
                    }
                }else{
                    Toast.makeText(MainCadastro.this, "As senhas não conferem", Toast.LENGTH_LONG).show();
                }





            }
        });


    }
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
}
