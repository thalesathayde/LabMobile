package com.example.samsung.login;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class TesteAct extends AppCompatActivity {

    String celular;
    EditText dbCelular;
    Button btnAtivar,btnDesativar,btnLocalizacao;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teste);

        btnAtivar = (Button)findViewById(R.id.btnAtivar);
        btnDesativar = (Button)findViewById(R.id.btnDesativar);
        btnLocalizacao = (Button)findViewById(R.id.btnImprimir);
        textView = (TextView)findViewById(R.id.identificador);




        btnAtivar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(TesteAct.this,"ATIVAR",Toast.LENGTH_LONG).show();
            }
        });

        btnDesativar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        btnLocalizacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });






    }



}
